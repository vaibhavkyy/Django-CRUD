from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages, auth
from companies.models import Companies
from .forms import CompaniesDetails
from django.contrib.auth.decorators import login_required


def index(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'User is not registed please sign up below')
            return redirect('login')
    return render(request, 'companies/login.html')


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
        else:
            messages.info(request, 'some error occurred,try using strong password')
            return redirect('register')
    else:
        form = UserCreationForm()
        return render(request, 'companies/register.html', {'form': form})


@login_required(login_url='/')
def home(request):
    if request.method == 'POST':
        cd = CompaniesDetails(request.POST)
        if cd.is_valid():
            nm = cd.cleaned_data['name']
            web = cd.cleaned_data['website']
            num = cd.cleaned_data['number']
            add = cd.cleaned_data['address']
            ct = cd.cleaned_data['city']
            st = cd.cleaned_data['state']
            cy = cd.cleaned_data['country']
            industry = cd.cleaned_data['industry_list']

            reg = Companies(name=nm, website=web, number=num, address=add,
                            city=ct, state=st, country=cy, industry_list=industry)
            reg.save()
            cd = CompaniesDetails()
    else:
        cd = CompaniesDetails()
    details = Companies.objects.all()
    return render(request, 'companies/home.html', {'form': cd, 'details': details})


@login_required(login_url='/')
def update(request, id):
    if request.method == 'POST':
        cd = Companies.objects.get(pk=id)
        res = CompaniesDetails(request.POST, instance=cd)
        if res.is_valid():
            res.save()
        return redirect('/')
    else:
        cd = Companies.objects.get(pk=id)
        res = CompaniesDetails(instance=cd)

    return render(request, 'companies/update.html', {'form': res})


def delete(request, id):
    if request.method == "POST":
        dl = Companies.objects.get(pk=id)
        dl.delete()
        return redirect('/')


def logout(request):
    auth.logout(request)
    return redirect('/')
