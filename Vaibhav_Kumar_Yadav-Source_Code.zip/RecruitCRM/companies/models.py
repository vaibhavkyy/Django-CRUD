from django.db import models

# Create your models here.

industries = (
    ('Account','Account'), ('IT','IT'), ('Sales','Sales'),('Health Care','Health Care')
)

class Companies(models.Model):
    name = models.CharField(max_length=70)
    website = models.URLField(max_length=100)
    number = models.CharField(max_length=15)
    address = models.CharField(max_length=200)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    country = models.CharField(max_length=50)
    industry_list = models.CharField(max_length=20,choices=industries, default='IT')


