from dataclasses import fields
from django import forms
from .models import Companies

class CompaniesDetails(forms.ModelForm):
    class Meta:
        model = Companies
        fields = '__all__'
        widgets = {
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'website':forms.URLInput(attrs={'class':'form-control'}),
            'number':forms.TextInput(attrs={'class':'form-control'}),
            'address':forms.TextInput(attrs={'class':'form-control'}),
            'city':forms.TextInput(attrs={'class':'form-control'}),
            'state':forms.TextInput(attrs={'class':'form-control'}),
            'country':forms.TextInput(attrs={'class':'form-control'}),
            'industry_list':forms.Select(attrs={'class':'form-control'}),
            
        }
